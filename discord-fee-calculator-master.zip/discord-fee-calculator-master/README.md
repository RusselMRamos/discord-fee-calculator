# Discord Fee Calculator Bot

Simple Discord bot that calculates fees for Stockx, PayPal, Ebay and Goat. 

### Setup

All that's neccesary for the bot to run is a bot token.

### Usage

The bot only has one command, which is `!fee <amount>` and it will reply with a RichEmbed.

### Example

When given the command `!fee 50`, this is what it will reply:

![Discord Bot Reply](https://i.imgur.com/Jnl7ELh.png)
